watchAttempt = 200
watchInterval = 1  # (s)

checkResultAttempt = 3

postSelectAttempt = 3

proxy = {
    # 'http':'http://127.0.0.1:8888'
}

MODE = 'Keyword'  # Keyword/Specific
# Keyword: 关键词抢课 将监视一切命中关键词的课程
# Specific： 在下方指定课程的关键信息 将循环监视下列指定课程

Course_Keyword = '管理心理学'

wantSelect = []

wantSelect.append({
    "kch": "999008030",
    "kxh": "01",
    "kcm": "中华文化（艺术篇）",
    "zxjxjhh": "2019-2020-1-1",
})

user_agent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36"

headers = {
    'User-Agent': user_agent,
    'Referer': 'http://zhjw.scu.edu.cn/student/courseSelect/courseSelect/index'
}

login_data = {
    'j_username': '2018141451247',
    'j_password': 'Xzl2Frn1314!',
    'j_captcha': 'error',
}

### 以下内容若无必要 请勿修改
### ————————————————————

login_url = "http://zhjw.scu.edu.cn/login/j_spring_security_check"
query_url = "http://zhjw.scu.edu.cn/student/courseSelect/freeCourse/courseList"
token_url = "http://zhjw.scu.edu.cn/student/courseSelect/courseSelect/index"
postToken_url = "http://zhjw.scu.edu.cn/student/courseSelect/selectCourse/checkInputCodeAndSubmit"
captcha_url = "http://zhjw.scu.edu.cn/student/courseSelect/selectCourse/getYzmPic?time=233"
select_url = "http://zhjw.scu.edu.cn/student/courseSelect/selectCourses/waitingfor"
result_url = "http://zhjw.scu.edu.cn/student/courseSelect/selectResult/query"

token_key = r"""<input type="hidden" id="tokenValue" value=".+"\/>"""
kcNum_key = "kcNum = \".+\""
redisKey_Key = "redisKey = \".+\""
